# Prizefighter Phase 8 Production Backend API Contract

Base path: `/api`

Sport rule: Prizefighter only accepts `Gloved Boxing` and `Bare Knuckle Boxing (BKB)`. All fighter signup, search and admin update routes must reject any other sport.

## Auth
- `POST /auth/register/fighter` creates pending fighter + profile.
- `POST /auth/register/fan` creates pending fan + profile.
- `POST /auth/login` returns session token.
- `POST /auth/logout` clears session.

## Search
- `GET /fighters/search?q=&sport=&country=&city=&weight=&verified=` returns public fighter cards.
- `GET /fighters/:id` returns full public fighter profile.

## Profiles
- `PATCH /fighters/me` updates fighter editable fields.
- `PATCH /fans/me` updates fan editable fields.
- `POST /verification` sends verification request.

## Social
- `POST /profiles/:id/posts` verified users only.
- `POST /posts/:id/comments` verified users only.
- `POST /reports` creates moderation report.

## Money Systems
- `POST /ads/enquiry` creates pending advertiser contract.
- `POST /plugins/:code/checkout` starts PayPal checkout/subscription.
- `POST /webhooks/paypal` updates plugin/ad status after payment events.

## Admin
- `GET /admin/dashboard`
- `GET /admin/verification-queue`
- `POST /admin/verify/:userId`
- `POST /admin/reject/:userId`
- `GET /admin/reports`
- `PATCH /admin/reports/:id`
- `GET /admin/money`
