/* Prizefighter Phase 9 PayPal webhook template
   This file is a production guide, not a complete live integration.
   Never activate plugins, adverts or sponsor slots from frontend button clicks only.
   Always verify the PayPal webhook signature on the backend first. */

import express from 'express';
const router = express.Router();

const PAYPAL_EVENTS_TO_PROCESS = new Set([
  'BILLING.SUBSCRIPTION.ACTIVATED',
  'BILLING.SUBSCRIPTION.RENEWED',
  'BILLING.SUBSCRIPTION.CANCELLED',
  'PAYMENT.SALE.COMPLETED',
  'PAYMENT.SALE.DENIED'
]);

async function verifyPayPalWebhookSignature(req) {
  // TODO: Call PayPal verify-webhook-signature API using:
  // PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_WEBHOOK_ID
  // Required headers include transmission id, time, cert url, auth algo and transmission sig.
  return false;
}

router.post('/api/webhooks/paypal', express.raw({ type: 'application/json' }), async (req, res) => {
  const verified = await verifyPayPalWebhookSignature(req);
  if (!verified) return res.status(401).json({ error: 'Invalid PayPal webhook signature' });

  const event = JSON.parse(req.body.toString('utf8'));
  if (!PAYPAL_EVENTS_TO_PROCESS.has(event.event_type)) return res.json({ ignored: true });

  // TODO:
  // 1. Upsert payment_events by event.id so processing is idempotent.
  // 2. Match event.resource.billing_agreement_id or subscription_id to profile_plugins/adverts/sponsors.
  // 3. Activate, renew, cancel or expire the matching contract.
  // 4. Create notification for the user/admin.
  res.json({ received: true });
});

export default router;
