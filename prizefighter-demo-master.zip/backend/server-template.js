/* Prizefighter Phase 8 backend template
   Runtime target: Node.js + Express + PostgreSQL.
   Prizefighter sport rule: ONLY Gloved Boxing and Bare Knuckle Boxing (BKB). */

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

const app = express();
const ALLOWED_SPORTS = ['Gloved Boxing', 'Bare Knuckle Boxing (BKB)'];

function isAllowedSport(s) {
  return ALLOWED_SPORTS.includes(String(s || '').trim());
}

function requireAllowedSport(req, res, next) {
  const sport = req.body?.sport || req.query?.sport;
  if (sport && !isAllowedSport(sport)) {
    return res.status(400).json({
      error: 'Invalid sport. Prizefighter only accepts Gloved Boxing and Bare Knuckle Boxing (BKB).'
    });
  }
  next();
}

app.use(helmet());
app.use(cors({ origin: process.env.APP_ORIGIN || '*' }));
app.use(express.json({ limit: '2mb' }));
app.use(rateLimit({ windowMs: 60_000, max: 120 }));

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'Prizefighter API', allowed_sports: ALLOWED_SPORTS }));

app.get('/api/fighters/search', requireAllowedSport, async (req, res) => {
  const { q = '', sport = '', country = '', city = '', weight = '', verified = '' } = req.query;
  // TODO: query fighter_profiles + users table using production-schema.sql.
  // WHERE sport IN allowed sports, and optionally sport = req.query.sport.
  res.json({ mode: 'template', q, sport, country, city, weight, verified, results: [] });
});

app.post('/api/auth/register/fighter', requireAllowedSport, async (req, res) => {
  // TODO: validate required fields, Facebook profile URL, BoxRec URL, then insert pending user/profile.
  // IMPORTANT: req.body.sport must be Gloved Boxing or Bare Knuckle Boxing (BKB).
  res.status(201).json({ status: 'pending', message: 'Fighter submitted for Prizefighter admin approval.' });
});

app.post('/api/auth/register/fan', async (_req, res) => {
  // TODO: create pending fan account and fan profile.
  res.status(201).json({ status: 'pending', message: 'Fan submitted for Prizefighter admin approval.' });
});

app.post('/api/auth/login', async (_req, res) => {
  // TODO: verify password hash and return JWT/session token.
  res.json({ mode: 'template', token: null });
});

app.post('/api/webhooks/paypal', async (req, res) => {
  // TODO: verify PayPal webhook signature before changing any plugin/ad status.
  // Store raw event in payment_events and process idempotently using provider_event_id.
  res.json({ received: true });
});

app.listen(process.env.PORT || 3000, () => console.log('Prizefighter Phase 8 API ready'));
