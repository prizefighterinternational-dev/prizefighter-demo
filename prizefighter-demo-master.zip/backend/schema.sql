-- PRIZEFIGHTER PHASE 7 DATABASE FOUNDATION
-- Target: PostgreSQL / Supabase / Railway Postgres

create table users (
  id uuid primary key default gen_random_uuid(),
  account_type text not null check (account_type in ('fighter','fan','admin')),
  email text unique not null,
  password_hash text not null,
  display_name text not null,
  passport_id text unique not null,
  verified boolean default false,
  status text default 'pending' check (status in ('pending','approved','rejected','suspended')),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table fighter_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete cascade,
  first_name text not null,
  last_name text not null,
  ring_name text,
  ring_walk_song text,
  city text,
  country text,
  country_code text,
  gym text,
  sport text not null default 'Bare Knuckle Boxing (BKB)' check (sport in ('Gloved Boxing','Bare Knuckle Boxing (BKB)')),
  weight_division text,
  stance text,
  height_cm int,
  reach_cm int,
  status text default 'Active',
  boxrec_url text,
  facebook_profile_url text,
  bio text check (length(bio) <= 700),
  profile_photo_url text,
  banner_url text,
  searchable_text text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table fan_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete cascade,
  city text,
  country text,
  country_code text,
  profile_photo_url text,
  bio text check (length(bio) <= 500),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table verification_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete cascade,
  request_type text not null,
  document_url text,
  notes text,
  status text default 'pending' check (status in ('pending','approved','rejected')),
  reviewed_by uuid references users(id),
  reviewed_at timestamptz,
  created_at timestamptz default now()
);

create table plugins (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  name text not null,
  price_usd numeric(10,2) default 0,
  period_days int default 28,
  requires_contract boolean default false,
  active boolean default true
);

create table profile_plugins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete cascade,
  plugin_id uuid references plugins(id),
  payment_provider text,
  payment_subscription_id text,
  status text default 'active' check (status in ('active','renew_due','expired','cancelled')),
  starts_at timestamptz default now(),
  expires_at timestamptz,
  created_at timestamptz default now()
);

create table sponsors (
  id uuid primary key default gen_random_uuid(),
  fighter_user_id uuid references users(id) on delete cascade,
  sponsor_name text not null,
  logo_url text,
  slot_number int default 1,
  status text default 'active',
  expires_at timestamptz
);

create table adverts (
  id uuid primary key default gen_random_uuid(),
  company_name text not null,
  contact_email text not null,
  logo_url text,
  landing_url text not null,
  placement text not null,
  price_usd numeric(10,2) default 500,
  period_days int default 28,
  contract_months int default 3,
  status text default 'pending' check (status in ('pending','active','expired','rejected')),
  starts_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz default now()
);

create table merch_products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  image_url text,
  price_usd numeric(10,2) not null,
  category text,
  featured boolean default false,
  active boolean default true,
  created_at timestamptz default now()
);

create table posts (
  id uuid primary key default gen_random_uuid(),
  profile_user_id uuid references users(id) on delete cascade,
  author_user_id uuid references users(id),
  body text not null,
  image_url text,
  created_at timestamptz default now()
);

create table comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid references posts(id) on delete cascade,
  author_user_id uuid references users(id),
  body text not null,
  created_at timestamptz default now()
);

create table reports (
  id uuid primary key default gen_random_uuid(),
  reporter_user_id uuid references users(id),
  target_type text not null,
  target_id text not null,
  reason text not null,
  details text,
  status text default 'new' check (status in ('new','reviewing','handled','dismissed')),
  created_at timestamptz default now()
);

create table messages (
  id uuid primary key default gen_random_uuid(),
  sender_user_id uuid references users(id),
  receiver_user_id uuid references users(id),
  body text not null,
  read_at timestamptz,
  created_at timestamptz default now()
);

create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete cascade,
  type text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz default now()
);

create table payment_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_event_id text unique not null,
  event_type text not null,
  raw_payload jsonb not null,
  processed_at timestamptz,
  created_at timestamptz default now()
);

create index fighter_search_idx on fighter_profiles using gin (to_tsvector('english', coalesce(searchable_text,'')));
create index adverts_status_idx on adverts(status, expires_at);
create index profile_plugins_status_idx on profile_plugins(status, expires_at);
