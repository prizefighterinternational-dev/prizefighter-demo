-- Prizefighter Phase 9 payment products seed
insert into plugins (code, name, price_usd, period_days, requires_contract, active)
values
  ('plugin-online-trainer', 'Online Trainer Plugin', 5.00, 30, false, true),
  ('plugin-sponsor-link', 'Sponsor Link Plugin', 9.00, 30, false, true),
  ('plugin-five-sponsors', 'Five Sponsor Slots', 500.00, 28, true, true),
  ('ad-scroll-slot', 'Scrolling Advertising Banner', 500.00, 28, true, true)
on conflict (code) do update set
  name = excluded.name,
  price_usd = excluded.price_usd,
  period_days = excluded.period_days,
  requires_contract = excluded.requires_contract,
  active = excluded.active;
